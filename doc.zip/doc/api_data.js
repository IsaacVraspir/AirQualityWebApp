define({ "api": [
  {
    "type": "Directory",
    "url": "/var/www/html/Web_UI_and_Server_Development/api",
    "title": "Store Token",
    "name": "store_tok",
    "group": "Login",
    "examples": [
      {
        "title": "Example function call:",
        "content": "store_tok(username, token)",
        "type": "php"
      }
    ],
    "success": {
      "fields": {
        "Success - Return ture": [
          {
            "group": "Success - Return ture",
            "type": "Boolean",
            "optional": false,
            "field": "returns",
            "description": "<p>a boolean true indicating that the token was successfully stored.</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error - User Not Signed In": [
          {
            "group": "Error - User Not Signed In",
            "type": "Boolean",
            "optional": false,
            "field": "returns",
            "description": "<p>a boolean false indicating that the token was not stored correctly.</p>"
          }
        ]
      }
    },
    "description": "<p>the store_tok function is used to store the login token for a user session in the database.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "username",
            "description": "<p>The username of the account for which the session token will be used.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "token",
            "description": "<p>The unique token for the active user that indicates what user is signed into an account on the device.</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./dbAPI.php",
    "groupTitle": "Login"
  },
  {
    "type": "Directory",
    "url": "/var/www/html/Web_UI_and_Server_Development/api",
    "title": "Create Message",
    "name": "create_message",
    "group": "Message",
    "examples": [
      {
        "title": "Example function call:",
        "content": "create_message(token, message_url, message_description)",
        "type": "php"
      }
    ],
    "success": {
      "fields": {
        "Success - Massage Added To Database": [
          {
            "group": "Success - Massage Added To Database",
            "type": "Boolean",
            "optional": false,
            "field": "Returns",
            "description": "<p>true if the message was added to the table successfully.</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error - Message": [
          {
            "group": "Error - Message",
            "type": "Boolean",
            "optional": false,
            "field": "Returns",
            "description": "<p>false if the user the message is supposed to be associate with is not signed in.</p>"
          }
        ]
      }
    },
    "description": "<p>The create message function is used to add a message that is recorded by a user to the database and assocciate it with the user account. NOTE: a message description is not required to be added for a message (can be NULL) but a name is required for the message (database will throw an error).</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "token",
            "description": "<p>The unique token for the active user that indicates what user is signed into an account on the device.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "message_url",
            "description": "<p>The string that is the file path needed to follow in order to load the message.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "message_name",
            "description": "<p>The string name that a user assigns to a message.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "message_description",
            "description": "<p>A string description of the message that the user can use to distiguish between messages.</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./dbAPI.php",
    "groupTitle": "Message"
  },
  {
    "type": "Directory",
    "url": "/var/www/html/Web_UI_and_Server_Development/api",
    "title": "Get Message",
    "name": "get_message_file",
    "group": "Message",
    "examples": [
      {
        "title": "Example function call:",
        "content": "get_message_file(token, message_id)",
        "type": "php"
      }
    ],
    "success": {
      "fields": {
        "Success - The URL of the audio file on the server": [
          {
            "group": "Success - The URL of the audio file on the server",
            "type": "String",
            "optional": false,
            "field": "Returns",
            "description": "<p>a String that is the file path to access the desired audio file on the server.</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error - Message": [
          {
            "group": "Error - Message",
            "type": "Boolean",
            "optional": false,
            "field": "Returns",
            "description": "<p>false if the message was not successfully pulled from the database.</p>"
          }
        ]
      }
    },
    "description": "<p>The get message file function is used to pull the file path of a wanted message from the database. This file path can then be used to access the audio file directly.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "token",
            "description": "<p>The unique token for the active user that indicates what user is signed into an account on the device.</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "message_id",
            "description": "<p>The unique id number for the message that is to be returned.</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./dbAPI.php",
    "groupTitle": "Message"
  },
  {
    "type": "Directory",
    "url": "/var/www/html/Web_UI_and_Server_Development/api",
    "title": "Get All Messages",
    "name": "get_usable_messages",
    "group": "Message",
    "examples": [
      {
        "title": "Example function call:",
        "content": "get_usable_messages(token)",
        "type": "php"
      }
    ],
    "success": {
      "fields": {
        "Success - All accessable messages returned": [
          {
            "group": "Success - All accessable messages returned",
            "type": "Array",
            "optional": false,
            "field": "Returns",
            "description": "<p>an array containing the defining data of all messages that the indicated user has access to )both their own and those shared with them).</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error - Message": [
          {
            "group": "Error - Message",
            "type": "Boolean",
            "optional": false,
            "field": "Returns",
            "description": "<p>false if the messages where not successfully pulled from the database.</p>"
          }
        ]
      }
    },
    "description": "<p>The get usable message function is used to get all of the relevant information about all of the messages that a user could set as an alarm message.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "token",
            "description": "<p>The unique token for the active user that indicates what user is signed into an account on the device.</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./dbAPI.php",
    "groupTitle": "Message"
  },
  {
    "type": "Directory",
    "url": "/var/www/html/Web_UI_and_Server_Development/api",
    "title": "Share Message",
    "name": "share_message",
    "group": "Message",
    "examples": [
      {
        "title": "Example function call:",
        "content": "share_message(token, friend_user_name, message_name)",
        "type": "php"
      }
    ],
    "success": {
      "fields": {
        "Success - Massage shared with friend": [
          {
            "group": "Success - Massage shared with friend",
            "type": "Boolean",
            "optional": false,
            "field": "Returns",
            "description": "<p>true if the message was shared successfully.</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error - Message": [
          {
            "group": "Error - Message",
            "type": "Boolean",
            "optional": false,
            "field": "Returns",
            "description": "<p>false if the message was not successfullly shared.</p>"
          }
        ]
      }
    },
    "description": "<p>The share message function is used to share or send a message between users. It will give the indicated friend access permission to the message indicated.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "token",
            "description": "<p>The unique token for the active user that indicates what user is signed into an account on the device.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "friend_user_name",
            "description": "<p>The username of the friend that the user untends to give access to the message.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "message_name",
            "description": "<p>The string name that a user assigns to a message.</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./dbAPI.php",
    "groupTitle": "Message"
  },
  {
    "type": "Directory",
    "url": "/var/www/html/Web_UI_and_Server_Development/api",
    "title": "Get User Information",
    "name": "get_user_information",
    "group": "Profile",
    "examples": [
      {
        "title": "Example function call:",
        "content": "get_user_information(token)",
        "type": "php"
      }
    ],
    "success": {
      "fields": {
        "Success - Return Information": [
          {
            "group": "Success - Return Information",
            "type": "array",
            "optional": false,
            "field": "userSignedIn",
            "description": "<p>The user is verified as signed in and returns the username, first and last name, phone number, email and profile picture associated with the user.</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error - User Not Signed In": [
          {
            "group": "Error - User Not Signed In",
            "type": "Boolean",
            "optional": false,
            "field": "userNotSignedIn",
            "description": "<p>returns a boolean of false indicating that the user is not signed in with a valid token.</p>"
          }
        ]
      }
    },
    "description": "<p>The get user information function is used to get profile information for the current active user on the device.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "token",
            "description": "<p>The unique token for the active user that indicates what user is signed into an account on the device.</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./dbAPI.php",
    "groupTitle": "Profile"
  },
  {
    "type": "Directory",
    "url": "/var/www/html/Web_UI_and_Server_Development/api",
    "title": "Create New User",
    "name": "new_usr",
    "group": "Profile",
    "examples": [
      {
        "title": "Example function call:",
        "content": "new_usr(usrname, email_addr, first_name, last_name, phone_num, prof_pic, password)",
        "type": "php"
      }
    ],
    "success": {
      "fields": {
        "Success - User Created": [
          {
            "group": "Success - User Created",
            "type": "Boolean",
            "optional": false,
            "field": "userCreated",
            "description": "<p>The user has been created, returns Boolean value of TRUE.</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error - User Not Created": [
          {
            "group": "Error - User Not Created",
            "type": "Boolean",
            "optional": false,
            "field": "userNotCreated",
            "description": "<p>The username already exists and will not be added to database, returns Boolean value of FALSE.</p>"
          }
        ]
      }
    },
    "description": "<p>The new user function creates front end functionality allowing for the creation of a new user in the database with basic information provided.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "usrname",
            "description": "<p>The username wanting to be stored.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "email_addr",
            "description": "<p>The user's email address.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "first_name",
            "description": "<p>The user's first name.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "last_name",
            "description": "<p>The user's last name.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "phone_num",
            "description": "<p>The user's phone number.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "prof_pic",
            "description": "<p>The path containing the the profile picture.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>The user's password.</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./dbAPI.php",
    "groupTitle": "Profile"
  },
  {
    "type": "Directory",
    "url": "/var/www/html/Web_UI_and_Server_Development/api",
    "title": "Update Profile Information",
    "name": "update_profile_information",
    "group": "Profile",
    "examples": [
      {
        "title": "Example function call:",
        "content": "update_profile_information(token, new_data, data_to_update)",
        "type": "php"
      }
    ],
    "success": {
      "fields": {
        "Success - Information Updated": [
          {
            "group": "Success - Information Updated",
            "type": "Boolean",
            "optional": false,
            "field": "Returns",
            "description": "<p>true if the update was successfully executed.</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "Error - Information Not Updated": [
          {
            "group": "Error - Information Not Updated",
            "type": "Boolean",
            "optional": false,
            "field": "Returns",
            "description": "<p>false if the information was not successfully updated.</p>"
          }
        ]
      }
    },
    "description": "<p>The update user information function is used to change an individual piece of profile information for a particular user.</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "token",
            "description": "<p>The unique token for the active user that indicates what user is signed into an account on the device.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "new_data",
            "description": "<p>The string input that is the new data to be stored in the database such as the new email address or name.</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "data_to_update",
            "description": "<p>The constant variable in the DB_conn class that identifies which piece of data is going to be updated.</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "./dbAPI.php",
    "groupTitle": "Profile"
  },
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "./doc/main.js",
    "group": "_var_www_html_Web_UI_and_Server_Development_api_doc_main_js",
    "groupTitle": "_var_www_html_Web_UI_and_Server_Development_api_doc_main_js",
    "name": ""
  }
] });
